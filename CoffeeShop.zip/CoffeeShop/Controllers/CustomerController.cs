﻿using CoffeeShop.Dal;
using CoffeeShop.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CoffeeShop.Controllers
{


    public class CustomerController : Controller
    {
   

        public ActionResult Index()
        {

            return View();
        }

        public ActionResult CustomerHome()

        {

            string c = (string)Session["home"];

            if (c == "F")
            {
                return RedirectToAction("ShowHomePage", "Home");
            }

            MenuViewModel mvm = new MenuViewModel();
            mvm.menue = new Menu();

            MenuDal db = new MenuDal();
            mvm.menues = db.Menues.ToList<Menu>();

            return View("CustomerHome", mvm);

        }

        public ActionResult PaymentSummary()
        {
            string c = (string)Session["home"];

            if (c == "F")
            {
                return RedirectToAction("ShowHomePage", "Home");
            }
            return View("PaymentSummary");
        }

        public ActionResult SeatSelect()
        {

            string c = (string)Session["home"];

            if (c == "F")
            {
                return RedirectToAction("ShowHomePage", "Home");
            }
            TableViewModel tvm = new TableViewModel();
            TableDal tdb = new TableDal();

            tvm.table = new Table();
            tvm.tables = tdb.Tables.ToList<Table>();

            return View("SeatSelect",tvm);
        }


        public ActionResult ContinueToPay()
        {
            string c = (string)Session["home"];

            if (c == "F")
            {
                return RedirectToAction("ShowHomePage", "Home");
            }
            return View("ContinueToPay", new PaymentModel());
        }

        public ActionResult Succeed()
        {
            string c = (string)Session["home"];

            if (c == "F")
            {
                return RedirectToAction("ShowHomePage", "Home");
            }
            return View("Succeed");
        }

        public ActionResult SubmitProducts()
        {

            string products = "[";
            MenuDal db = new MenuDal();
            int Price = 0;

            

            if (Request.Form["c1"] == "1")
            {
                var mytab = db.Menues.First(g => g.Name == "BlackCoffee");

                if (mytab.Availability == "F")
                {
                    ViewBag.err = "BlackCoffee not Available";
                    MenuViewModel mvm = new MenuViewModel();
                    mvm.menue = new Menu();

                    MenuDal db1 = new MenuDal();
                    mvm.menues = db1.Menues.ToList<Menu>();

                    return View("CustomerHome", mvm);

                }
                Price +=( Convert.ToInt32(mytab.Price.ToString()) - 1);
                products += "BlackCoffee ";
            }


            if (Request.Form["c2"] == "1")
            {
                var mytab = db.Menues.First(g => g.Name == "Cappuccino");


                if (mytab.Availability == "F")
                {
                    ViewBag.err = "Cappuccino not Available";
                    MenuViewModel mvm = new MenuViewModel();
                    mvm.menue = new Menu();

                    MenuDal db1 = new MenuDal();
                    mvm.menues = db1.Menues.ToList<Menu>();

                    return View("CustomerHome", mvm);

                }
                Price += (Convert.ToInt32(mytab.Price.ToString()) - 1);
                products += "Cappuccino ";
            }


            if (Request.Form["c3"] == "1")
            {
                var mytab = db.Menues.First(g => g.Name == "ChocolateMilk");

                if (mytab.Availability == "F")
                {
                    ViewBag.err = "ChocolateMilk not Available";
                    MenuViewModel mvm = new MenuViewModel();
                    mvm.menue = new Menu();

                    MenuDal db1 = new MenuDal();
                    mvm.menues = db1.Menues.ToList<Menu>();

                    return View("CustomerHome", mvm);

                }
                Price += (Convert.ToInt32(mytab.Price.ToString()) - 1);
                products += "ChocolateMilk ";
            }


            if (Request.Form["c4"] == "1")
            {
                var mytab = db.Menues.First(g => g.Name == "MilkShake");

                if (mytab.Availability == "F")
                {
                    ViewBag.err = "MilkShake not Available";
                    MenuViewModel mvm = new MenuViewModel();
                    mvm.menue = new Menu();

                    MenuDal db1 = new MenuDal();
                    mvm.menues = db1.Menues.ToList<Menu>();

                    return View("CustomerHome", mvm);

                }
                Price += (Convert.ToInt32(mytab.Price.ToString()) - 1);
                products += "MilkShake ";
            }

            if (Request.Form["c5"] == "1")
            {
                var mytab = db.Menues.First(g => g.Name == "ChocolateCroissant");

                if (mytab.Availability == "F")
                {
                    ViewBag.err = "ChocolateCroissant not Available";
                    MenuViewModel mvm = new MenuViewModel();
                    mvm.menue = new Menu();

                    MenuDal db1 = new MenuDal();
                    mvm.menues = db1.Menues.ToList<Menu>();

                    return View("CustomerHome", mvm);

                }
                Price += (Convert.ToInt32(mytab.Price.ToString()) - 1);
                products += "ChocolateCroissant ";
            }

            if (Request.Form["c6"] == "1")
            {
                var mytab = db.Menues.First(g => g.Name == "PinkRoseCroissant");

                if (mytab.Availability == "F")
                {
                    ViewBag.err = "PinkRoseCroissant not Available";
                    MenuViewModel mvm = new MenuViewModel();
                    mvm.menue = new Menu();

                    MenuDal db1 = new MenuDal();
                    mvm.menues = db1.Menues.ToList<Menu>();

                    return View("CustomerHome", mvm);

                }
                Price += (Convert.ToInt32(mytab.Price.ToString()) - 1);
                products += "PinkRoseCroissant ";
            }

            if (Request.Form["c7"] == "1")
            {
                var mytab = db.Menues.First(g => g.Name == "ButterCroissant");

                if (mytab.Availability == "F")
                {
                    ViewBag.err = "ButterCroissant not Available";
                    MenuViewModel mvm = new MenuViewModel();
                    mvm.menue = new Menu();

                    MenuDal db1 = new MenuDal();
                    mvm.menues = db1.Menues.ToList<Menu>();

                    return View("CustomerHome", mvm);

                }
                Price += (Convert.ToInt32(mytab.Price.ToString()) - 1);
                products += "ButterCroissant ";
            }

            if (Request.Form["c8"] == "1")
            {
                var mytab = db.Menues.First(g => g.Name == "PistachioCroissant");

                if (mytab.Availability == "F")
                {
                    ViewBag.err = "PistachioCroissant not Available";
                    MenuViewModel mvm = new MenuViewModel();
                    mvm.menue = new Menu();

                    MenuDal db1 = new MenuDal();
                    mvm.menues = db1.Menues.ToList<Menu>();

                    return View("CustomerHome", mvm);

                }
                Price += (Convert.ToInt32(mytab.Price.ToString()) - 1);
                products += "PistachioCroissant ";
            }

            if (Request.Form["c9"] == "1")
            {
                var mytab = db.Menues.First(g => g.Name == "CheeseBorax");

                if (mytab.Availability == "F")
                {
                    ViewBag.err = "CheeseBorax not Available";
                    MenuViewModel mvm = new MenuViewModel();
                    mvm.menue = new Menu();

                    MenuDal db1 = new MenuDal();
                    mvm.menues = db1.Menues.ToList<Menu>();

                    return View("CustomerHome", mvm);

                }

                Price += (Convert.ToInt32(mytab.Price.ToString()) - 1);
                products += "CheeseBorax ";
            }

            if (Request.Form["c10"] == "1")
            {
                var mytab = db.Menues.First(g => g.Name == "PotatoBorax");
                
                if (mytab.Availability == "F")
                {
                    ViewBag.err = "PotatoBorax not Available";
                    MenuViewModel mvm = new MenuViewModel();
                    mvm.menue = new Menu();

                    MenuDal db1 = new MenuDal();
                    mvm.menues = db1.Menues.ToList<Menu>();

                    return View("CustomerHome", mvm);

                }
                Price += (Convert.ToInt32(mytab.Price.ToString()) - 1);
                products += "PotatoBorax ";
            }

            if (Request.Form["c11"] == "1")
            {
                var mytab = db.Menues.First(g => g.Name == "OmeletSandwich");

                if (mytab.Availability == "F")
                {
                    ViewBag.err = "OmeletSandwich not Available";
                    MenuViewModel mvm = new MenuViewModel();
                    mvm.menue = new Menu();

                    MenuDal db1 = new MenuDal();
                    mvm.menues = db1.Menues.ToList<Menu>();

                    return View("CustomerHome", mvm);

                }
                Price += (Convert.ToInt32(mytab.Price.ToString()) - 1);
                products += "OmeletSandwich ";
            }

            if (Request.Form["c12"] == "1")
            {
                var mytab = db.Menues.First(g => g.Name == "TunaSandwich");

                if (mytab.Availability =="F")
                {
                    ViewBag.err = "TunaSandwich not Available";
                    MenuViewModel mvm = new MenuViewModel();
                    mvm.menue = new Menu();

                    MenuDal db1 = new MenuDal();
                    mvm.menues = db1.Menues.ToList<Menu>();

                    return View("CustomerHome", mvm);

                }

                Price += (Convert.ToInt32(mytab.Price.ToString()) - 1);
                products += "TunaSandwich ";
            }

            products = products+ ']' ;

            


            
            Session["product"] = products;
            Session["price"] = Price;


            if(Price == 0)
            {
                ViewBag.err = "Please choose something";
                MenuViewModel mvm = new MenuViewModel();
                mvm.menue = new Menu();

                MenuDal db1 = new MenuDal();
                mvm.menues = db1.Menues.ToList<Menu>();

                return View("CustomerHome", mvm);

            }

            TableViewModel tvm = new TableViewModel();
            TableDal tdb = new TableDal();

            tvm.table = new Table();
            tvm.tables = tdb.Tables.ToList<Table>();

            return View("SeatSelect", tvm);
        }




        public ActionResult GoToSummary()
        {

            TableDal db = new TableDal();
            string idtable = Request.Form["tablenum"];

            var mytab = db.Tables.Any(x => x.id == idtable);

            if (mytab)
            {

                foreach (Table t in db.Tables)
                {

                    if (t.id == idtable) 
                    { 
                        if (t.Availability == "T")
                         {
                            Session["table"] = t.id;
                       
                            return RedirectToAction("PaymentSummary", "Customer");
                         }
                         else
                        {
                             ViewBag.err = "Table is not available!";

                            TableViewModel tvm = new TableViewModel();
                            TableDal tdb = new TableDal();

                            tvm.table = new Table();
                            tvm.tables = tdb.Tables.ToList<Table>();

                            return View("SeatSelect", tvm);
                        }
                    }
                }

            }

            else
            {
                ViewBag.err = "Table is not exist!";
                
                TableViewModel tvm = new TableViewModel();
                TableDal tdb = new TableDal();

                tvm.table = new Table();
                tvm.tables = tdb.Tables.ToList<Table>();

                return View("SeatSelect", tvm);
            }

            return RedirectToAction("ShowHomePage", "Home");
        }

        public ActionResult PaySubmit(PaymentModel pay)
        {
            if (ModelState.IsValid)
            {
                StaticVar.count();

                Orders order = new Orders
                {

                    NumOrder = StaticVar.getNum().ToString(),
                    Products = (string)Session["product"],
                    Table = (string)Session["table"]
                };

                string var = (string)Session["table"];
                TableDal tb = new TableDal();
                var mytab = tb.Tables.First(g => g.id == var);
                mytab.Availability = "F";
                tb.SaveChanges();


                OrderDal db = new OrderDal();

                db.orders.Add(order);
                db.SaveChanges();

                return View("Succeed");
            }
            else
            {
                
                return View("ContinueToPay", pay);
            }
        }
    }
}