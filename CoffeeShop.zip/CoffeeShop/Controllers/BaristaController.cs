﻿using CoffeeShop.Dal;
using CoffeeShop.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.UI.WebControls;
using Table = CoffeeShop.Models.Table;

namespace CoffeeShop.Controllers
{
    public class BaristaController : Controller
    {
        // GET: Barista
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult BaristaHome()
        {

            string c = (string)Session["home"];

            if (c == "F")
            {
                return RedirectToAction("ShowHomePage", "Home");
            }
            return View("BaristaHome");
        }

        public ActionResult AcceptOrders()
        {

            string c = (string)Session["home"];

            if (c == "F")
            {
                return RedirectToAction("ShowHomePage", "Home");
            }

            OrderViewModel tvm = new OrderViewModel();
            OrderDal tdb = new OrderDal();

            tvm.order = new Orders();
            tvm.orders = tdb.orders.ToList<Orders>();

            return View("AcceptOrders", tvm);
        }

        public ActionResult TableRelease()
        {
            string c = (string)Session["home"];

            if (c == "F")
            {
                return RedirectToAction("ShowHomePage", "Home");
            }

            TableViewModel tvm = new TableViewModel();
            TableDal tdb = new TableDal();

            tvm.table = new Table();
            tvm.tables = tdb.Tables.ToList<Table>();
            return View("TableRelease", tvm);
        }


        public ActionResult Release()
        {
            TableDal tb = new TableDal();
            string var = Request.Form["TableNumber"];


            var mytab1 = tb.Tables.Any(x => x.id == var);

            if (mytab1)
            {
                var mytab = tb.Tables.First(g => g.id == var);
                mytab.Availability = "T";
                tb.SaveChanges();

            }
            TableViewModel tvm = new TableViewModel();
            TableDal tdb = new TableDal();

            tvm.table = new Table();
            tvm.tables = tdb.Tables.ToList<Table>();

            return View("TableRelease", tvm);
        }

        public ActionResult DeleteOrder()
        {
            OrderDal db = new OrderDal();
            string var = Request.Form["Delete"];

            var mytab1 = db.orders.Any(x => x.NumOrder == var);

            if (mytab1)
            {
                var mytab = db.orders.First(g => g.NumOrder == var);
                db.orders.Remove(mytab);
                db.SaveChanges();
            }


            OrderViewModel tvm = new OrderViewModel();
            OrderDal tdb = new OrderDal();

            tvm.order = new Orders();
            tvm.orders = tdb.orders.ToList<Orders>();

            return View("AcceptOrders", tvm);
        }
    }
}