﻿using CoffeeShop.Dal;
using CoffeeShop.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;




namespace CoffeeShop.Controllers
{
    public class AdminController : Controller
    {
        // GET: Admin
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult AdminHome(string admin)
        {
            string c = (string)Session["home"];

                 if (c == "F")
                 {
                      return RedirectToAction("ShowHomePage","Home");
                 }

            return View("AdminHome", admin);
        }

        public ActionResult ChangeSeats()
        {

            string c = (string)Session["home"];

            if (c == "F")
            {
                return RedirectToAction("ShowHomePage", "Home");
            }
            return View("ChangeSeats");
        }

        public ActionResult ChangeMenu()
        {

            string c = (string)Session["home"];

            if (c == "F")
            {
                return RedirectToAction("ShowHomePage", "Home");
            }
            return View("ChangeMenu");
        }

        public ActionResult ChangeTheMenu()
        {
            MenuDal db = new MenuDal();
                


            if (Request.Form["changeblackcoffeeprice"] != "")
            {
                var mytab = db.Menues.First(g => g.Name == "BlackCoffee");
                mytab.Price = Request.Form["changeblackcoffeeprice"];
                db.SaveChanges();
            }

            if (Request.Form["changeblackcoffeeav"] != "")
            {
                var mytab = db.Menues.First(g => g.Name == "BlackCoffee");
                mytab.Availability = Request.Form["changeblackcoffeeav"];
                db.SaveChanges();
            }

            
            
           
            
            if (Request.Form["changecappuccinoprice"] != "")
            {
                var mytab = db.Menues.First(g => g.Name == "Cappuccino");
                mytab.Price = Request.Form["changecappuccinoprice"];
                db.SaveChanges();
            }

            if (Request.Form["changecappuccinoav"] != "")
            {
                var mytab = db.Menues.First(g => g.Name == "Cappuccino");
                mytab.Availability = Request.Form["changecappuccinoav"];
                db.SaveChanges();
            }







            if (Request.Form["changechocolatemilkprice"] != "")
            {
                var mytab = db.Menues.First(g => g.Name == "ChocolateMilk");
                mytab.Price = Request.Form["changechocolatemilkprice"];
                db.SaveChanges();
            }

            if (Request.Form["changechocolatemilkav"] != "")
            {
                var mytab = db.Menues.First(g => g.Name == "ChocolateMilk");
                mytab.Availability = Request.Form["changechocolatemilkav"];
                db.SaveChanges();
            }






            if (Request.Form["changemilkshakeprice"] != "")
            {
                var mytab = db.Menues.First(g => g.Name == "MilkShake");
                mytab.Price = Request.Form["changemilkshakeprice"];
                db.SaveChanges();

            }

            if (Request.Form["changemilkshakeav"] != "")
            {
                var mytab = db.Menues.First(g => g.Name == "MilkShake");
                mytab.Availability = Request.Form["changemilkshakeav"];
                db.SaveChanges();

            }



            if (Request.Form["changechocolatecroissantprice"] != "")
            {
                var mytab = db.Menues.First(g => g.Name == "ChocolateCroissant");
                mytab.Price = Request.Form["changechocolatecroissantprice"];
                db.SaveChanges();
            }

            if (Request.Form["changechocolatecroissantav"] != "")
            {
                var mytab = db.Menues.First(g => g.Name == "ChocolateCroissant");
                mytab.Availability = Request.Form["changechocolatecroissantav"];
                db.SaveChanges();
            }





            if (Request.Form["changepinkroseprice"] != "")
            {
                var mytab = db.Menues.First(g => g.Name == "PinkRoseCroissant");
                mytab.Price = Request.Form["changepinkroseprice"];
                db.SaveChanges();
            }

            if (Request.Form["changepinkroseav"] != "")
            {
                var mytab = db.Menues.First(g => g.Name == "PinkRoseCroissant");
                mytab.Availability = Request.Form["changepinkroseav"];
                db.SaveChanges();
            }
            



            if (Request.Form["changebutterprice"] != "")
            {
                var mytab = db.Menues.First(g => g.Name == "ButterCroissant");
                mytab.Price = Request.Form["changebutterprice"];
                db.SaveChanges();
            }

            if (Request.Form["changebutterav"] != "")
            {
                var mytab = db.Menues.First(g => g.Name == "ButterCroissant");
                mytab.Availability = Request.Form["changebutterav"];
                db.SaveChanges();
            }






            if (Request.Form["changepistachioprice"] != "")
            {
                var mytab = db.Menues.First(g => g.Name == "PistachioCroissant");
                mytab.Price = Request.Form["changepistachioprice"];
                db.SaveChanges();
            }

            if (Request.Form["changepistachioav"] != "")
            {
                var mytab = db.Menues.First(g => g.Name == "PistachioCroissant");
                mytab.Availability = Request.Form["changepistachioav"];
                db.SaveChanges();
            }






            if (Request.Form["changecheeseboraxprice"] != "")
            {
                var mytab = db.Menues.First(g => g.Name == "CheeseBorax");
                mytab.Price = Request.Form["changecheeseboraxprice"];
                db.SaveChanges();
            }

            if (Request.Form["changecheeseboraxav"] != "")
            {
                var mytab = db.Menues.First(g => g.Name == "CheeseBorax");
                mytab.Availability = Request.Form["changecheeseboraxav"];
                db.SaveChanges();
            }



            if (Request.Form["changepotatoboraxprice"] != "")
            {
                var mytab = db.Menues.First(g => g.Name == "PotatoBorax");
                mytab.Price = Request.Form["changepotatoboraxprice"];
                db.SaveChanges();
            }

            if (Request.Form["changepotatoboraxav"] != "")
            {
                var mytab = db.Menues.First(g => g.Name == "PotatoBorax");
                mytab.Availability = Request.Form["changepotatoboraxav"];
                db.SaveChanges();
            }



            if (Request.Form["changeomletprice"] != "")
            {
                var mytab = db.Menues.First(g => g.Name == "OmeletSandwich");
                mytab.Price = Request.Form["changeomletprice"];
                db.SaveChanges();
            }

            if (Request.Form["changeomletav"] != "")
            {
                var mytab = db.Menues.First(g => g.Name == "OmeletSandwich");
                mytab.Availability = Request.Form["changeomletav"];
                db.SaveChanges();
            }




            if (Request.Form["changetunaprice"] != "")
            {
                var mytab = db.Menues.First(g => g.Name == "TunaSandwich");
                mytab.Price = Request.Form["changetunaprice"];
                db.SaveChanges();
            }

            if (Request.Form["changetunaav"] != "")
            {
                var mytab = db.Menues.First(g => g.Name == "TunaSandwich");
                mytab.Availability = Request.Form["changetunaav"];
                db.SaveChanges();
            }
         


            return View("AdminHome");
        }

        public ActionResult ChangeTables()
        {

            TableDal db = new TableDal();


            if (Request.Form["t1"] != "")
            {
                var mytab = db.Tables.First(g => g.id == "1");
                mytab.Availability = Request.Form["t1"];
                db.SaveChanges();
            }


            if (Request.Form["t2"] != "")
            {
                var mytab = db.Tables.First(g => g.id == "2");
                mytab.Availability = Request.Form["t2"];
                db.SaveChanges();
            }


            if (Request.Form["t3"] != "")
            {
                var mytab = db.Tables.First(g => g.id == "3");
                mytab.Availability = Request.Form["t3"];
                db.SaveChanges();
            }


            if (Request.Form["t4"] != "")
            {
                var mytab = db.Tables.First(g => g.id == "4");
                mytab.Availability = Request.Form["t4"];
                db.SaveChanges();
            }

            if (Request.Form["t5"] != "")
            {
                var mytab = db.Tables.First(g => g.id == "5");
                mytab.Availability = Request.Form["t5"];
                db.SaveChanges();
            }

            if (Request.Form["t6"] != "")
            {
                var mytab = db.Tables.First(g => g.id == "6");
                mytab.Availability = Request.Form["t6"];
                db.SaveChanges();
            }

            if (Request.Form["t7"] != "")
            {
                var mytab = db.Tables.First(g => g.id == "7");
                mytab.Availability = Request.Form["t7"];
                db.SaveChanges();
            }

            if (Request.Form["t8"] != "")
            {
                var mytab = db.Tables.First(g => g.id == "8");
                mytab.Availability = Request.Form["t8"];
                db.SaveChanges();
            }


            if (Request.Form["t9"] != "")
            {
                var mytab = db.Tables.First(g => g.id == "9");
                mytab.Availability = Request.Form["t9"];
                db.SaveChanges();
            }

            if (Request.Form["t10"] != "")
            {
                var mytab = db.Tables.First(g => g.id == "10");
                mytab.Availability = Request.Form["t10"];
                db.SaveChanges();
            }

            if (Request.Form["t11"] != "")
            {
                var mytab = db.Tables.First(g => g.id == "11");
                mytab.Availability = Request.Form["t11"];
                db.SaveChanges();
            }

            if (Request.Form["t12"] != "")
            {
                var mytab = db.Tables.First(g => g.id == "12");
                mytab.Availability = Request.Form["t12"];
                db.SaveChanges();
            }

            if (Request.Form["t13"] != "")
            {
                var mytab = db.Tables.First(g => g.id == "13");
                mytab.Availability = Request.Form["t13"];
                db.SaveChanges();
            }


            return View("AdminHome", new Admin());

        }
    }
}