﻿using CoffeeShop.Dal;
using CoffeeShop.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;


namespace CoffeeShop.Controllers
{

    
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }


        public ActionResult CodePage()
        {
            return View("CodePage");
        }
        public ActionResult ShowHomePage()
        {
            Session["home"] = "F";

            return View("home");
        }

        public ActionResult Register()
        {
            return View("registration", new RegisterViewModel());
        }

        public ActionResult Login()
        {
            return View("home", new LoginViewModel());
        }


        public ActionResult MenuPage()
        {
            MenuViewModel mvm = new MenuViewModel();
            mvm.menue = new Menu();

            MenuDal db = new MenuDal();
            mvm.menues = db.Menues.ToList<Menu>();

            return View("MenuPage", mvm);
        }

        public ActionResult SubLogin(LoginViewModel log)
        {
            if ("Barista" == Request.Form["duty"])
            {

                BaristaDal db = new BaristaDal();
                var userexist = db.Baristas.Any(x => x.Username == log.Username);
                var userexist2 = db.Baristas.Any(x => x.Username == log.Username && x.Password == log.Password);

                if (!userexist)
                {
                    ModelState.AddModelError("Username", "User with this name not exists");
                    return View("home", log);
                }
                else if (!userexist2)
                {
                    ModelState.AddModelError("Password", "The password is incorrect!");
                    return View("home", log);

                }
                else
                {
                    Session["home"] = "T";
                    return RedirectToAction("BaristaHome", "Barista") ;
                }


            }

            else if ("Client" == Request.Form["duty"])
            {

                CustomerDal db = new CustomerDal();
                var userexist = db.Customers.Any(x => x.Username == log.Username);
                var userexist2 = db.Customers.Any(x => x.Username == log.Username && x.Password == log.Password);

                if (!userexist)
                {
                    ModelState.AddModelError("Username", "User with this name not exists");
                    return View("home", log);
                }
                else if (!userexist2)
                {
                    ModelState.AddModelError("Password", "The password is incorrect!");
                    return View("home", log);

                }
                else

                {
                    Session["home"] = "T";
                    return RedirectToAction("CustomerHome", "Customer");
                }
            }

            else if ("Admin" == Request.Form["duty"])
            {

                AdminDal db = new AdminDal();
                var userexist = db.Admins.Any(x => x.Username == log.Username);
                var userexist2 = db.Admins.Any(x => x.Username == log.Username && x.Password == log.Password);

                if (!userexist)
                {
                    ModelState.AddModelError("Username", "User with this name not exists");
                    return View("home", log);
                }
                else if (!userexist2)
                {
                    ModelState.AddModelError("Password", "The password is incorrect!");
                    return View("home", log);
                }
                else

                {
                    Session["home"] = "T";
                    return RedirectToAction("AdminHome", "Admin", log.Username);
                }
            }

            return View("home");



        }

        public ActionResult SubmitReg(RegisterViewModel reg)
        {

            if ("Barista" == Request.Form["duty"])
            {
                if (ModelState.IsValid)
                {
                    BaristaDal db = new BaristaDal();
                    var userexist = db.Baristas.Any(x => x.Username == reg.Username);

                    if (userexist)
                    {
                        ModelState.AddModelError("Username", "User with this name already exists");
                        return View("registration", reg);
                    }
                    else

                    {
                        Session["username"] = reg.Username;
                        Session["password"] = reg.Password;
                        Session["email"] = reg.Email;

                        return RedirectToAction("CodePage", "Home");
                    }
                }
                else
                {
                    return View("registration", reg);
                }
            }

            else if ("Client" == Request.Form["duty"])
            {
                if (ModelState.IsValid)
                {
                    CustomerDal db = new CustomerDal();
                    var userexist = db.Customers.Any(x => x.Username == reg.Username);

                    if (userexist)
                    {
                        ModelState.AddModelError("Username", "User with this name already exists");
                        return View("registration", reg);
                    }
                    else

                    {
                        Customer customer = reg.GetCustomer();
                        db.Customers.Add(customer);
                        db.SaveChanges();
                        return View("home");
                    }
                }
                else
                {
                    return View("registration", reg);
                }
            }

            return View("registration");
        }


        public ActionResult EnterCode()
        {


            if(Request.Form["Code"] == "A1208")
            {
                Barista barista = new Barista
                {
                    Username = (string)Session["username"],
                    Password = (string)Session["password"],
                    Email = (string)Session["email"]
                };

                BaristaDal db = new BaristaDal();

                db.Baristas.Add(barista);
                db.SaveChanges();
                return View("home");
            }

            ViewBag.err = "Wrong code!";
            return View("CodePage");


        }




        public ActionResult SubmitProducts()
        {

            string products = "[";
            MenuDal db = new MenuDal();
            int Price = 0;



            if (Request.Form["c1"] == "1")
            {
                var mytab = db.Menues.First(g => g.Name == "BlackCoffee");

                if (mytab.Availability == "F")
                {
                    ViewBag.err = "BlackCoffee not Available";
                    MenuViewModel mvm = new MenuViewModel();
                    mvm.menue = new Menu();

                    MenuDal db1 = new MenuDal();
                    mvm.menues = db1.Menues.ToList<Menu>();

                    return View("MenuPage", mvm);

                }
                Price += (Convert.ToInt32(mytab.Price.ToString()) );
                products += "BlackCoffee ";
            }


            if (Request.Form["c2"] == "1")
            {
                var mytab = db.Menues.First(g => g.Name == "Cappuccino");

                if (mytab.Availability == "F")
                {
                    ViewBag.err = "Cappuccino not Available";
                    MenuViewModel mvm = new MenuViewModel();
                    mvm.menue = new Menu();

                    MenuDal db1 = new MenuDal();
                    mvm.menues = db1.Menues.ToList<Menu>();

                    return View("MenuPage", mvm);

                }
                Price += (Convert.ToInt32(mytab.Price.ToString()) );
                products += "Cappuccino ";
            }


            if (Request.Form["c3"] == "1")
            {
                var mytab = db.Menues.First(g => g.Name == "ChocolateMilk");

                if (mytab.Availability == "F")
                {
                    ViewBag.err = "ChocolateMilk not Available";
                    MenuViewModel mvm = new MenuViewModel();
                    mvm.menue = new Menu();

                    MenuDal db1 = new MenuDal();
                    mvm.menues = db1.Menues.ToList<Menu>();

                    return View("MenuPage", mvm);

                }
                Price += (Convert.ToInt32(mytab.Price.ToString()) );
                products += "ChocolateMilk ";
            }


            if (Request.Form["c4"] == "1")
            {
                var mytab = db.Menues.First(g => g.Name == "MilkShake");

                if (mytab.Availability == "F")
                {
                    ViewBag.err = "MilkShake not Available";
                    MenuViewModel mvm = new MenuViewModel();
                    mvm.menue = new Menu();

                    MenuDal db1 = new MenuDal();
                    mvm.menues = db1.Menues.ToList<Menu>();

                    return View("MenuPage", mvm);

                }
                Price += (Convert.ToInt32(mytab.Price.ToString()));
                products += "MilkShake ";
            }

            if (Request.Form["c5"] == "1")
            {
                var mytab = db.Menues.First(g => g.Name == "ChocolateCroissant");

                if (mytab.Availability == "F")
                {
                    ViewBag.err = "ChocolateCroissant not Available";
                    MenuViewModel mvm = new MenuViewModel();
                    mvm.menue = new Menu();

                    MenuDal db1 = new MenuDal();
                    mvm.menues = db1.Menues.ToList<Menu>();

                    return View("MenuPage", mvm);

                }
                Price += (Convert.ToInt32(mytab.Price.ToString()) );
                products += "ChocolateCroissant ";
            }

            if (Request.Form["c6"] == "1")
            {
                var mytab = db.Menues.First(g => g.Name == "PinkRoseCroissant");

                if (mytab.Availability == "F")
                {
                    ViewBag.err = "PinkRoseCroissant not Available";
                    MenuViewModel mvm = new MenuViewModel();
                    mvm.menue = new Menu();

                    MenuDal db1 = new MenuDal();
                    mvm.menues = db1.Menues.ToList<Menu>();

                    return View("MenuPage", mvm);

                }
                Price += (Convert.ToInt32(mytab.Price.ToString()) );
                products += "PinkRoseCroissant ";
            }

            if (Request.Form["c7"] == "1")
            {
                var mytab = db.Menues.First(g => g.Name == "ButterCroissant");

                if (mytab.Availability == "F")
                {
                    ViewBag.err = "ButterCroissant not Available";
                    MenuViewModel mvm = new MenuViewModel();
                    mvm.menue = new Menu();

                    MenuDal db1 = new MenuDal();
                    mvm.menues = db1.Menues.ToList<Menu>();

                    return View("MenuPage", mvm);

                }
                Price += (Convert.ToInt32(mytab.Price.ToString()) );
                products += "ButterCroissant ";
            }

            if (Request.Form["c8"] == "1")
            {
                var mytab = db.Menues.First(g => g.Name == "PistachioCroissant");

                if (mytab.Availability == "F")
                {
                    ViewBag.err = "PistachioCroissant not Available";
                    MenuViewModel mvm = new MenuViewModel();
                    mvm.menue = new Menu();

                    MenuDal db1 = new MenuDal();
                    mvm.menues = db1.Menues.ToList<Menu>();

                    return View("MenuPage", mvm);

                }
                Price += (Convert.ToInt32(mytab.Price.ToString()) );
                products += "PistachioCroissant ";
            }

            if (Request.Form["c9"] == "1")
            {
                var mytab = db.Menues.First(g => g.Name == "CheeseBorax");

                if (mytab.Availability == "F")
                {
                    ViewBag.err = "CheeseBorax not Available";
                    MenuViewModel mvm = new MenuViewModel();
                    mvm.menue = new Menu();

                    MenuDal db1 = new MenuDal();
                    mvm.menues = db1.Menues.ToList<Menu>();

                    return View("MenuPage", mvm);

                }
                Price += (Convert.ToInt32(mytab.Price.ToString()) );
                products += "CheeseBorax ";
            }

            if (Request.Form["c10"] == "1")
            {
                var mytab = db.Menues.First(g => g.Name == "PotatoBorax");

                if (mytab.Availability == "F")
                {
                    ViewBag.err = "PotatoBorax not Available";
                    MenuViewModel mvm = new MenuViewModel();
                    mvm.menue = new Menu();

                    MenuDal db1 = new MenuDal();
                    mvm.menues = db1.Menues.ToList<Menu>();

                    return View("MenuPage", mvm);

                }
                Price += (Convert.ToInt32(mytab.Price.ToString()) );
                products += "PotatoBorax ";
            }

            if (Request.Form["c11"] == "1")
            {
                var mytab = db.Menues.First(g => g.Name == "OmeletSandwich");

                if (mytab.Availability == "F")
                {
                    ViewBag.err = "OmeletSandwich not Available";
                    MenuViewModel mvm = new MenuViewModel();
                    mvm.menue = new Menu();

                    MenuDal db1 = new MenuDal();
                    mvm.menues = db1.Menues.ToList<Menu>();

                    return View("MenuPage", mvm);

                }
                Price += (Convert.ToInt32(mytab.Price.ToString()));
                products += "OmeletSandwich ";
            }

            if (Request.Form["c12"] == "1")
            {
                var mytab = db.Menues.First(g => g.Name == "TunaSandwich");

                if (mytab.Availability == "F")
                {
                    ViewBag.err = "TunaSandwich not Available";
                    MenuViewModel mvm = new MenuViewModel();
                    mvm.menue = new Menu();

                    MenuDal db1 = new MenuDal();
                    mvm.menues = db1.Menues.ToList<Menu>();

                    return View("MenuPage", mvm);

                }
                Price += (Convert.ToInt32(mytab.Price.ToString()) );
                products += "TunaSandwich ";
            }


            products = products + ']';
            Session["product"] = products;
            Session["price"] = Price;


            if (Price == 0)
            {
                ViewBag.err = "Please choose something";
                MenuViewModel mvm = new MenuViewModel();
                mvm.menue = new Menu();

                MenuDal db1 = new MenuDal();
                mvm.menues = db1.Menues.ToList<Menu>();

                return View("MenuPage", mvm);

            }

            TableViewModel tvm = new TableViewModel();
            TableDal tdb = new TableDal();

            tvm.table = new Table();
            tvm.tables = tdb.Tables.ToList<Table>();

            return View("SeatSelect", tvm);
        }

        public ActionResult PaymentSummary()
        {
            return View("PaymentSummary");
        }


        public ActionResult About()
        {
            return View("About");
        }

        public ActionResult Contact()
        {
            return View("contact");
        }

        public ActionResult SeatSelect()
        {
            TableViewModel tvm = new TableViewModel();
            TableDal tdb = new TableDal();

            tvm.table = new Table();
            tvm.tables = tdb.Tables.ToList<Table>();

            return View("SeatSelect", tvm);
        }


        public ActionResult ContinueToPay()
        {

            return View("ContinueToPay", new PaymentModel());
        }

        public ActionResult Succeed()
        {
            return View("Succeed");
        }

        public ActionResult GoToSummary()
        {

            TableDal db = new TableDal();
            string idtable = Request.Form["tablenum"];

            var mytab = db.Tables.Any(x => x.id == idtable);

            if (mytab)
            {

                foreach (Table t in db.Tables)
                {

                    if (t.id == idtable)
                    {
                        if (t.Availability == "T")
                        {
                            Session["table"] = t.id;

                            return RedirectToAction("PaymentSummary", "Home");
                        }
                        else
                        {
                            ViewBag.err = "Table is not available!";

                            TableViewModel tvm = new TableViewModel();
                            TableDal tdb = new TableDal();

                            tvm.table = new Table();
                            tvm.tables = tdb.Tables.ToList<Table>();

                            return View("SeatSelect", tvm);
                        }
                    }
                }

            }
            else
            {
                ViewBag.err = "Table is not exist!";

                TableViewModel tvm = new TableViewModel();
                TableDal tdb = new TableDal();

                tvm.table = new Table();
                tvm.tables = tdb.Tables.ToList<Table>();

                return View("SeatSelect", tvm);
            }

            return RedirectToAction("ShowHomePage", "Home");
        }

        public ActionResult PaySubmit(PaymentModel pay)
        {
            if (ModelState.IsValid)
            {
                StaticVar.count();

                Orders order = new Orders
                {

                    NumOrder = StaticVar.getNum().ToString(),
                    Products = (string)Session["product"],
                    Table = (string)Session["table"]
                };



                TableDal tb = new TableDal();
                string var = (string)Session["table"];

                var mytab = tb.Tables.First(g => g.id == var);
                mytab.Availability = "F";
                tb.SaveChanges();


                OrderDal db = new OrderDal();
                db.orders.Add(order);
                db.SaveChanges();

                return View("Succeed");
            }
            else
            {

                return View("ContinueToPay", pay);
            }
        }
    }
}