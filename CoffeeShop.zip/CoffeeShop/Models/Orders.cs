﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CoffeeShop.Models
{
    public class Orders
    {

        public string NumOrder { get; set; }
        public string Products { get; set; }

        [Key]
        public string Table { get; set; }

    }
}