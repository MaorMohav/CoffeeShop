﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CoffeeShop.Models
{
    public static class StaticVar
    {
        public static int num = 0;

        public static void count()
        {
            num++;
        }
        public static int getNum()
        {
            return num;
        }
    }
}