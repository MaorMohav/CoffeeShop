﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CoffeeShop.Models
{
    public class MenuViewModel
    {
        public Menu menue { get; set; }
        public List<Menu> menues { get; set; }
    }
}