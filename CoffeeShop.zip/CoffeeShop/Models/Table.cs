﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CoffeeShop.Models
{
    public class Table
    {
        [Key]
        public string id { get; set; }
        public string Availability { get; set; }
    }
}