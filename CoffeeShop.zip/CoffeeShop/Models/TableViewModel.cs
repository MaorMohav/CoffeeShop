﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CoffeeShop.Models
{
    public class TableViewModel
    {

        public Table table { get; set; }
        public List<Table> tables { get; set; }
    }
}