﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CoffeeShop.Models
{ 
    public class PaymentModel
    {

        [Display(Name = "Name on Card")]
        [Required(ErrorMessage = "This field is required")]
        public string NameonCard { get; set; }

        [Display(Name = "Credit Card Number")]
        [Required(ErrorMessage = "This field is required, input valid 16 digit number")]
        [RegularExpression("^[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]$", ErrorMessage ="Credit card invalid!, you need 16 digits without spaces")]
        public string CreditCardNum { get; set; }

        [Display(Name = "Expiration Date")]
        [Required(ErrorMessage = "This field is required, input valid expiration date: MM/YY")]
        [RegularExpression(@"([0-9][0-9])\/([0-9][0-9])", ErrorMessage = "Date invalid!, input valid expiration date: MM/YY")]
        public string ExpDate { get; set; }

        [Display(Name = "CVV")]
        [RegularExpression(@"([0-9][0-9][0-9])", ErrorMessage ="CVV invalid!, you need to enter 3 digits")]
        [Required(ErrorMessage = "This field is required")]
        public string cvv { get; set; }
    }
}