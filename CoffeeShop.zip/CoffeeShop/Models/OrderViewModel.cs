﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CoffeeShop.Models
{
    public class OrderViewModel
    {

        public Orders order { get; set; }
        public List<Orders> orders { get; set; }
    }
}