﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CoffeeShop.Models
{
    public class Barista
    {
        [Key]
        [Required]
        [StringLength(30, MinimumLength = 2, ErrorMessage = "Username must be between 2 and 30 letters")]
        public string Username { get; set; }

        [Required]
        [StringLength(30, MinimumLength = 6, ErrorMessage = "Password must be between 6 and 30 letters")]
        public string Password { get; set; }

        [Required]
        [StringLength(30, MinimumLength = 4, ErrorMessage = "Email must be between 4 and 30 letters")]
        public string Email { get; set; }
    }
}