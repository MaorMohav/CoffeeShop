﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CoffeeShop.Models
{
    public class Menu
    {

        [Key]
        public string Name { get; set; }
        public string Price { get; set; }

        public string Availability { get; set; }


    }
}